# Observações do usuário (resumo; ler antes de mexer)
- Aparelho: TV Samsung 2024 (Tizen), sem copiar/colar; digita tudo à mão -> comandos curtos.
- Ditado por voz (webtermv4): funciona SÓ em frases longas (~10-20 palavras). Frase curta ou 1 palavra NÃO é enviada. Outros terminais: nada ou várias tentativas. Causa desconhecida; diagnosticar com &dbg=1 (bash r.sh d lê o log).
- Setup: instalar opencode com: curl -fsSL https://opencode.ai/v2/install|bash (usado para testar interface de terminal gráfico). Já está no r.sh s.
- Preferir criar arquivos/scripts reutilizáveis a repetir comandos longos.
- Versões: tags git (bash r.sh t NOME / v NOME). agentgit apaga em 24h sem push.
- Log do ditado (dbg=1): palavra curta chega como keydown 229 -> beforeinput insertText -> input, mas o campo acumula o texto (VAL) e nada vai ao shell. Hipótese: só vai quando tem caractere não-ASCII (filtro na=/[^\x00-\x7f]/ do term.html); frases longas em português quase sempre têm acento. Teste: "não"/"você" curtos devem funcionar; "oi"/"sim" não.
- Backup "4 palavras funcionam": tag 4-palavras-funcionam + backups/ocw3-4-palavras-funcionam.tar.gz (+ log dbg-4-palavras-funcionam.log). Restaurar: git clone ...; git checkout 4-palavras-funcionam  (ou tar xzf).
- Espera final do túnel reduzida de 165 s para 80 s (e.sh). A skill tunel (somente leitura) ainda cita 165/170: o e.sh manda.
- v4.1b: servidor grava linhas IN (o que realmente chegou ao shell, textos com mais de 1 caractere) em /tmp/wt-dbg.log quando dbg=1.
