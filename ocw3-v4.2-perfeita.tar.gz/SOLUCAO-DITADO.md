# Ditado por voz no webtermv4: SOLUCIONADO na v4.2 (LER PRIMEIRO)
Confirmado pelo usuário (TV Samsung, teclado de voz): funciona com 1 palavra ou frase longa, com ou sem acento. Versão mais perfeita até agora. Tag: **v4.2-perfeita**.

## Sintoma
Ditado só enviava ao shell frases longas; palavra curta ("oi") não era enviada.

## Causa raiz (2 partes)
1. O xterm.js 5.5.0 descarta texto de voz/IME que chega depois de keydown com keyCode 229. Ele compara o campo de texto num setTimeout de 0 ms (_handleAnyTextareaChanges) e o texto da voz chega depois; o caminho do evento input também é bloqueado por (!e.composed||!this._keyDownSeen). Bug conhecido e ainda aberto no projeto: https://github.com/xtermjs/xterm.js/pull/6009 , https://github.com/xtermjs/xterm.js/issues/6045 , https://github.com/xtermjs/xterm.js/issues/6185
2. O nosso term.html só interceptava o ditado se o texto tivesse caractere não-ASCII (filtro na=/[^\x00-\x7f]/). Frase longa em português quase sempre tem acento, então "parecia" que o tamanho importava; palavra curta sem acento caía no xterm e sumia.

## Como foi descoberto
- Modo dbg=1 (term.html) grava os eventos em /tmp/wt-dbg.log do servidor; bash r.sh d lê. Mostrou keydown 229 -> beforeinput -> input, o campo acumulando texto (linhas VAL) e que só frases com acento eram interceptadas.
- Leitura do código do xterm (node_modules/@xterm/xterm/lib/xterm.js) e busca de issues no GitHub (API api.github.com/search/issues).
- Linhas IN (v4.1b, server.js) mostram o que realmente chegou ao shell.

## Solução (v4.2, term.html)
beforeinput insertText até 1,5 s depois de keydown 229 vai direto ao shell com preventDefault+stopImmediatePropagation (variável k9), com ou sem acento. Teclado físico não gera 229, então não duplica. Reconexão do websocket 2 s -> 0,5 s.

## Se quebrar de novo
1. Abrir com &dbg=1, ditar, bash r.sh d. Comparar beforeinput com IN: beforeinput sem IN = perdido no navegador/ws.
2. Se atualizar o xterm, reavaliar: a correção local pode ficar redundante ou duplicar.
3. Rollback: git checkout v4.2-perfeita (ou tar xzf backups/ocw3-v4.2-perfeita.tar.gz). Estado antigo: tag 4-palavras-funcionam.
4. Aviso: agentgit apaga o repositório 24 h após o último push; espelhar no GitHub.
