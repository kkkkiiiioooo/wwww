# Contexto
Repo de orientacao para agentes. O produto e o webterm (apps/webtermv1): terminal no navegador, baseado na UI do opencode v1.3.9 (MIT) sem o servidor do agente, com mini-servidor Node (ws + @lydell/node-pty). Alvo de uso: TV/dispositivos sem copiar/colar, entrada por teclado virtual.
