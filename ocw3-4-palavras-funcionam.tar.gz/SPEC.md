# ESPECIFICACAO

## Proposito
Este arquivo define a especificacao de trabalho do repositorio.

## Objetivo primario
Transformar o estado atual do desktop no estado desejado em que somente o terminal permanece visivel.

## Entradas
- `screenshot/estado_atual_tela_completa.png`
- `screenshot/estado_desejado_apenas_terminal.png`
- `VISUAL_RULES.md`
- `SCREEN_INTENT.md`
- `ui_state/current.json`
- `ui_state/desired.json`
- `ocr/`

## Comportamento esperado
1. Interpretar o estado atual corretamente.
2. Interpretar o estado desejado corretamente.
3. Preferir o entendimento por imagens quando a visao estiver disponivel.
4. Usar OCR e arquivos estruturados somente como fallback para agentes sem visao.
5. Produzir acoes no desktop repetiveis.

## Criterios de sucesso
- Somente o terminal esta visivel no estado final.
- A imagem do estado atual nao e confundida com o estado desejado.
- O agente segue as regras do repositorio e as regras de interacao com o usuario.
