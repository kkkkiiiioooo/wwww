# ocw3

Repositorio de documentacao do projeto.

## Referencias visuais

Este repositorio inclui duas imagens importantes para orientacao dos agentes.

- `screenshot/estado_atual_tela_completa.png` = estado atual antes da limpeza
- `screenshot/estado_desejado_apenas_terminal.png` = estado desejado depois da limpeza

Importante:

- A imagem da tela completa do desktop e apenas um registro de como as coisas estavam antes.
- A imagem somente do terminal e o resultado final esperado.
- Os agentes nao devem confundir a imagem do estado atual com a imagem do estado alvo.

Para instrucoes mais rigorosas, veja `VISUAL_RULES.md`, `AGENTS.md` e `CONTEXT.md`.

## Partida rapida (prompt de uma linha)
Cole para o agente: repositorio ocw3: git clone https://agentgit.co/ocw3.git, leia AGENTS.md e execute.
