# Sessao

## Proposito
Rastrear a sessao de trabalho atual do agente.

## Campos
- current_task (tarefa atual)
- active_files (arquivos ativos)
- blockers (impedimentos)
- next_step (proxima etapa)
- handoff_needed (transferencia necessaria)

## Regra de atualizacao
Atualize este arquivo durante o trabalho ativo quando o estado da tarefa mudar.
