# Arquitetura
Navegador (dist/ estatico) <-HTTP/WS-> apps/webtermv1/server.js (Node: ws + @lydell/node-pty) <-> shell.
- HTTP: serve dist/; rotas desconhecidas respondem vazio.
- WS: um PTY por aba; resize e dados.
- Auth: TOKEN na query.
- build.sh: clona opencode v1.3.9, aplica alteracoes, gera dist/ (~2 GB RAM).
- Alternativa minima (se build nao for possivel): pagina HTML com xterm.js servida pelo mesmo server.js.
