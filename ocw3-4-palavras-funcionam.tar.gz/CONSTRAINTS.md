# Restricoes

## Restricoes operacionais
- Prefira instrucoes deterministicas em vez de orientacao vaga
- Mantenha a nomenclatura autoexplicativa
- Evite duplicacao desnecessaria entre arquivos
- Prefira caminhos de arquivos estaveis para referencias dos agentes

## Restricoes visuais
- `screenshot/estado_atual_tela_completa.png` e o estado atual
- `screenshot/estado_desejado_apenas_terminal.png` e o estado desejado
- Estado final desejado: somente o terminal permanece visivel

## Restricoes de agentes
- Agentes com capacidade de visao devem priorizar interpretacao baseada em imagens
- Agentes sem visao devem usar SCREEN_INTENT.md, VISUAL_RULES.md, ocr/ e ui_state/
