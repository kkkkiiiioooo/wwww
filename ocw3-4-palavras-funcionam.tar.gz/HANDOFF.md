# Handoff
Feito: docs consistentes (AGENTS.md entrada unica), caminhos screenshot/, aceite em CHECKLIST.md.
Aberto: validar webterm (CHECKLIST.md); build.sh pesado (2 GB RAM); teclado virtual nao testado.
Proximo: ler AGENTS.md, executar PLAN.md.
Inspecionar primeiro: apps/webtermv1/server.js, apps/webtermv1/README.md.
