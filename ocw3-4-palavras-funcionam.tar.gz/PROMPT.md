# PROMPT (intencao viva do humano; fonte unica do objetivo)
Agente: leia depois do FEEDBACK.md e siga AGENTS.md. Humano: edite livremente; limite de ~30 linhas.

## Objetivo
Construir e rodar sua propria versao do webterm: pagina web com SOMENTE um terminal (abas Terminal 1/2 e "+"), servida por mini-servidor PTY.

## Contexto
Uso em TV/dispositivos sem copiar e colar; entrada por teclado virtual. Base: apps/webtermv1.

## Restricoes
Sandbox sem navegador e com pouca RAM; preferir solucoes prontas e poucas linhas; sempre com TOKEN.

## Aceite
CHECKLIST.md completo, com prova no TESTLOG.md.

## Proibido
Ler imagens sem autorizacao; features alem de abas, PTY, token e teclado virtual.

## Prioridade atual
1. FB-001: teclado virtual deve abrir ao focar o terminal.
2. Validar server.js (CHECKLIST.md itens 1 a 4).

## Alvo visual
screenshot/estado_desejado_apenas_terminal.png (alvo); estado_atual_* NAO e alvo.

## Sugestoes de melhoria (so o agente escreve aqui; humano promove ao corpo)
- (vazio)

## Versoes
- v1 2026-10-17: criado a partir do antigo GOAL.md
