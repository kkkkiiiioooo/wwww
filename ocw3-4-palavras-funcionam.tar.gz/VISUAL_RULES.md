# Regras visuais
- screenshot/estado_atual_tela_completa.png = antes (varios elementos visiveis). NAO e o alvo.
- screenshot/estado_desejado_apenas_terminal.png = alvo (so o terminal, abas Terminal 1/2 e "+").
- Em conflito, a imagem vence o OCR.
- Alvo final: nenhuma outra janela/elemento competindo com o terminal.
