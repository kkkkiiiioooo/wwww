# ocw3 Constitution

## Core Principles
### I. Reuso antes de codigo
Preferir solucoes existentes (apps/webtermv1, xterm.js) a codigo novo. Comandos curtos.
### II. Seguranca por padrao
Nenhum servidor sem TOKEN. Sem token: 401.
### III. Prova, nao palavra
Item so esta pronto com linha no TESTLOG.md. Teclado virtual so o humano valida.
### IV. Documento e a interface
O humano fala com agentes pelos docs (PROMPT.md, FEEDBACK.md). Agente nao muda PROMPT.md sozinho.
### V. Leveza
Cabe em sandbox pequeno; sem navegador; referencia 60 MB RSS.

## Restricoes
Entrada por teclado virtual, sem copiar e colar. Imagens so com autorizacao do humano.

## Governance
Esta constituicao prevalece sobre PLAN.md e TASKS.md. Mudancas: via humano, registradas no CHANGELOG.md.
**Version**: 1.0.0 | **Ratified**: 2026-10-17
