# Decisoes

## Decisao 001
Usar arquivos markdown explicitos para separar objetivos, memoria, roteiro, contexto e regras de execucao.

Motivo:
- mais facil para os agentes analisarem
- mais facil para os humanos localizarem a intencao
- reduz a ambiguidade entre arquivos

## Decisao 002
Usar duas referencias visuais com significados diferentes.

Arquivos:
- `screenshot/estado_atual_tela_completa.png`
- `screenshot/estado_desejado_apenas_terminal.png`

Motivo:
- o estado atual nao deve ser confundido com o estado desejado
- a saida alvo deve permanecer obvia

## Decisao 003
Usar OCR e estado estruturado da interface somente como fallback para agentes sem visao.

Motivo:
- agentes com capacidade de visao devem confiar primeiro na evidencia visual direta
- agentes sem visao ainda precisam de uma representacao textual confiavel
