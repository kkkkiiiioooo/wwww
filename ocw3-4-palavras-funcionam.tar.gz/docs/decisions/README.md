# Decisoes detalhadas
Uma decisao por arquivo (NNN-titulo.md). Resumo em DECISIONS.md.
