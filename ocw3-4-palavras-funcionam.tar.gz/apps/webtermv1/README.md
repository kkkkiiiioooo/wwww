# termcc: opencode v1.3.9 so com o terminal + mini-servidor PTY

Tela igual a imagem desejada (abas Terminal 1/2 e "+"), sem o servidor do agente.

## Usar
- sh run.sh   (faz build, inicia o servidor e abre no navegador)
- TOKEN=segredo OPEN_HOST=127.0.0.1 sh run.sh
- HOST=0.0.0.0 TOKEN=segredo OPEN_HOST=IP_DA_MAQUINA sh run.sh

## Usar manual
- sh build.sh   (clona o opencode v1.3.9, aplica as alteracoes, gera dist/ e instala as dependencias)
- node server.js   e abrir http://127.0.0.1:5173/

Rede (TV): HOST=0.0.0.0 TOKEN=segredo node server.js e abrir http://IP:5173/?t=segredo
Variaveis: HOST, PORT, TOKEN, DIST, SHELL

## Arquivos
- server.js: mini-servidor Node (~150 linhas): PTY real, WebSocket do PTY, respostas vazias nas outras rotas
- build.sh: gera dist/ (precisa de git, python3, curl e node/npm)
- package.json: dependencias (ws, @lydell/node-pty)

## Requisitos do build
- Cerca de 2 GB de RAM livre ou swap. Em maquina de 1 GB o vite e morto por falta de memoria ("Killed")
- Internet (github.com, npm, bun.sh)

## Medido (sandbox Ubuntu 24)
- node server.js com 2 terminais: 60 MB RSS (opencode serve original: 366 MB)

## Nao testado
- Teclado virtual real (botao &#9000; injetado em dist/index.html via kb.html; validar no dispositivo)
- build.sh completo nao foi concluido na maquina do Composio (1 GB de RAM); o dist original foi compilado em outro sandbox com os mesmos passos

## Aviso
Sem TOKEN, quem acessar tem shell completo. Licenca: opencode e MIT (Copyright 2025 opencode).
