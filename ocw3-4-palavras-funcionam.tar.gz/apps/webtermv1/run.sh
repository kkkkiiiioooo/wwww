#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")"

HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-5173}"
TOKEN="${TOKEN:-segredo}"
OPEN_HOST="${OPEN_HOST:-127.0.0.1}"

export HOST PORT TOKEN

if [ "${WEBTERMV1_ALREADY_BUILT:-0}" != "1" ]; then
  WEBTERMV1_RUN_AFTER_BUILD=0 sh build.sh
fi

node server.js &
SERVER_PID=$!
trap 'kill "$SERVER_PID"' EXIT INT TERM

sleep 2
"${BROWSER:-xdg-open}" "http://$OPEN_HOST:$PORT/?t=$TOKEN" >/dev/null 2>&1 || true

wait "$SERVER_PID"
