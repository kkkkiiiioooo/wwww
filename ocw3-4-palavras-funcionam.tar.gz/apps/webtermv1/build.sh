#!/bin/sh
# Gera dist/ a partir do opencode v1.3.9 com so o terminal. Precisa de git, python3, curl.
set -e
command -v bun >/dev/null || { curl -fsSL https://bun.sh/install | bash; export PATH="$HOME/.bun/bin:$PATH"; }
command -v npm >/dev/null || { curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash - && sudo apt-get install -y nodejs; }
rm -rf oc dist && git clone -q -b v1.3.9 --depth 1 https://github.com/anomalyco/opencode.git oc
cd oc/packages/app
cat > src/pages/terminal-only.tsx <<'E'
import { TerminalPanel } from "@/pages/session/terminal-panel"

export default function TerminalOnly() {
  return (
    <div class="h-dvh w-screen overflow-hidden bg-background-stronger">
      <TerminalPanel />
    </div>
  )
}
E
python3 - <<'E'
def edit(p, pairs):
    s = open(p).read()
    for a, b in pairs:
        assert a in s, (p, a)
        s = s.replace(a, b)
    open(p, 'w').write(s)
edit('src/app.tsx', [
  ('<Route path="/" component={HomeRoute} />', '<Route path="/" component={() => <Navigate href="/Lw/session" />} />'),
  ('const HomeRoute = lazy(() => import("@/pages/home"))\n', ''),
  ('import("@/pages/session")', 'import("@/pages/terminal-only")'),
  ('import Layout from "@/pages/layout"\n', ''),
  ('<Layout>{props.children}</Layout>', '{props.children}'),
])
edit('src/pages/session/terminal-panel.tsx', [
  ('const opened = createMemo(() => view().terminal.opened())', 'const opened = createMemo(() => true)'),
  ('const pane = () => Math.min(height(), max())', 'const pane = () => store.view'),
])
E
cd ../.. && bun install --filter '@opencode-ai/app'
cd packages/app && bunx vite build
cd ../../.. && cp -r oc/packages/app/dist dist && rm -rf oc
echo "dist/ pronto"
npm i --omit=dev
if [ "${WEBTERMV1_RUN_AFTER_BUILD:-1}" = "1" ]; then
  WEBTERMV1_ALREADY_BUILT=1 exec sh ./run.sh
fi

# teclado virtual
python3 -c "p=\"dist/index.html\";s=open(p).read();k=open(\"kb.html\").read();open(p,\"w\").write(s.replace(\"</body>\",k+\"</body>\",1))"
