// ocmini: serve o front-end do opencode (dist/) e implementa só o PTY; o resto responde vazio.
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os')
const { WebSocketServer } = require('ws')
const pty = require('@lydell/node-pty')

const HOST = process.env.HOST || '127.0.0.1', PORT = +process.env.PORT || 5173, TOKEN = process.env.TOKEN
const DIST = path.resolve(process.env.DIST || path.join(__dirname, 'dist'))
const LIMIT = 2 * 1024 * 1024
const MIME = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.wasm': 'application/wasm',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2', '.woff': 'font/woff' }

const now = Date.now()
const project = { id: 'global', worktree: '/', time: { created: now, updated: now }, sandboxes: [] }
const dirOf = (q) => q.headers['x-opencode-directory'] ? decodeURIComponent(q.headers['x-opencode-directory']) : '/'
const STUB = {
  '/global/health': () => ({ healthy: true, version: '1.3.9' }),
  '/path': (q) => ({ home: os.homedir(), state: os.tmpdir(), config: os.tmpdir(), worktree: '/', directory: dirOf(q) }),
  '/vcs': () => ({}), '/session': () => [], '/session/status': () => ({}), '/question': () => [],
  '/project': () => [project], '/project/current': () => project, '/permission': () => [], '/mcp': () => ({}),
  '/config': () => ({ agent: {}, mode: {}, plugin: [], command: {}, username: 'unknown' }),
  '/global/config': () => ({}), '/command': () => [], '/agent': () => [],
  '/provider': () => ({ all: [], default: {}, connected: [] }),
}

// ---- PTY ----
const sessions = new Map(), sse = new Set()
const B62 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
const rnd = (n) => Array.from({ length: n }, () => B62[Math.floor(Math.random() * 62)]).join('')
const emit = (dir, type, properties) => { const m = `data: ${JSON.stringify({ directory: dir, payload: { type, properties } })}\n\n`; for (const r of sse) r.write(m) }
const meta = (cursor) => Buffer.concat([Buffer.from([0]), Buffer.from(JSON.stringify({ cursor }))])

function create(input, dir) {
  const id = 'pty_' + now.toString(16).slice(-8) + rnd(18)
  const command = input.command || process.env.SHELL || 'bash'
  const args = input.args || (/(ba|z|fi)?sh$/.test(command) ? ['-l'] : [])
  const cwd = input.cwd || dir
  const proc = pty.spawn(command, args, { name: 'xterm-256color', cols: 80, rows: 24, cwd,
    env: { ...process.env, ...input.env, TERM: 'xterm-256color', OPENCODE_TERMINAL: '1' } })
  const info = { id, title: input.title || `Terminal ${id.slice(-4)}`, command, args, cwd, status: 'running', pid: proc.pid }
  const s = { info, proc, dir, buffer: '', bufferCursor: 0, cursor: 0, subs: new Set() }
  sessions.set(id, s)
  proc.onData((chunk) => {
    s.cursor += chunk.length
    for (const ws of s.subs) ws.readyState === 1 ? ws.send(chunk) : s.subs.delete(ws)
    s.buffer += chunk
    if (s.buffer.length > LIMIT) { const x = s.buffer.length - LIMIT; s.buffer = s.buffer.slice(x); s.bufferCursor += x }
  })
  proc.onExit(({ exitCode }) => { if (info.status === 'exited') return; info.status = 'exited'; emit(dir, 'pty.exited', { id, exitCode }); remove(id) })
  emit(dir, 'pty.created', { info })
  return info
}
function remove(id) {
  const s = sessions.get(id); if (!s) return
  sessions.delete(id); try { s.proc.kill() } catch {}
  for (const ws of s.subs) ws.close(); emit(s.dir, 'pty.deleted', { id })
}

// ---- HTTP ----
const json = (r, v, c = 200) => { r.writeHead(c, { 'content-type': 'application/json' }); r.end(JSON.stringify(v)) }
const body = (q) => new Promise((ok) => { let d = ''; q.on('data', (c) => (d += c)); q.on('end', () => { try { ok(JSON.parse(d || '{}')) } catch { ok({}) } }) })
const authed = (q) => !TOKEN || new URL(q.url, 'http://x').searchParams.get('t') === TOKEN || /(?:^|; )t=([^;]+)/.exec(q.headers.cookie || '')?.[1] === TOKEN

const srv = http.createServer(async (q, r) => {
  const u = new URL(q.url, 'http://x'), p = u.pathname
  if (TOKEN && !authed(q)) return json(r, { error: 'unauthorized' }, 401)
  if (u.searchParams.get('t') === TOKEN && TOKEN) r.setHeader('set-cookie', `t=${TOKEN}; Path=/; SameSite=Strict`)
  if (STUB[p]) return json(r, STUB[p](q))
  if (p === '/global/event' || p === '/event') {
    r.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'keep-alive' })
    r.write('data: {"payload":{"type":"server.connected","properties":{}}}\n\n')
    sse.add(r); const k = setInterval(() => r.write(': ka\n\n'), 20000)
    return q.on('close', () => { sse.delete(r); clearInterval(k) })
  }
  if (p === '/pty' && q.method === 'GET') return json(r, [...sessions.values()].map((s) => s.info))
  if (p === '/pty' && q.method === 'POST') return json(r, create(await body(q), dirOf(q)))
  const m = /^\/pty\/([^/]+)$/.exec(p)
  if (m) {
    const s = sessions.get(m[1])
    if (q.method === 'DELETE') { remove(m[1]); return json(r, true) }
    if (!s) return json(r, { name: 'NotFoundError', data: { message: 'Session not found' } }, 404)
    if (q.method === 'PUT') {
      const b = await body(q)
      if (b.title) s.info.title = b.title
      if (b.size) s.proc.resize(b.size.cols, b.size.rows)
      emit(s.dir, 'pty.updated', { info: s.info })
    }
    return json(r, s.info)
  }
  // estático + SPA
  let f = path.join(DIST, p === '/' ? 'index.html' : p)
  if (!f.startsWith(DIST) || !fs.existsSync(f) || !fs.statSync(f).isFile()) {
    if (!(q.headers.accept || '').includes('text/html')) return json(r, {}, 404)
    f = path.join(DIST, 'index.html')
  }
  r.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' })
  fs.createReadStream(f).pipe(r)
})

const wss = new WebSocketServer({ noServer: true })
srv.on('upgrade', (q, sock, head) => {
  const u = new URL(q.url, 'http://x'), m = /^\/pty\/([^/]+)\/connect$/.exec(u.pathname), s = m && sessions.get(m[1])
  if (!s || !authed(q)) return sock.destroy()
  wss.handleUpgrade(q, sock, head, (ws) => {
    const c = u.searchParams.get('cursor'), n = c === null ? undefined : Number(c)
    const end = s.cursor, from = n === -1 ? end : Number.isSafeInteger(n) && n >= 0 ? n : 0
    if (from < end) { const off = Math.max(0, from - s.bufferCursor); if (off < s.buffer.length) { const d = s.buffer.slice(off); for (let i = 0; i < d.length; i += 64 * 1024) ws.send(d.slice(i, i + 64 * 1024)) } }
    ws.send(meta(end)); s.subs.add(ws)
    ws.on('message', (d) => s.proc.write(d.toString()))
    ws.on('close', () => s.subs.delete(ws))
  })
})
srv.listen(PORT, HOST, () => console.log(`http://${HOST}:${PORT}/${TOKEN ? '?t=' + TOKEN : ''}`))
