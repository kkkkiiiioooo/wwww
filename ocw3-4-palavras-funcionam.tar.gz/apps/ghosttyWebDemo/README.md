# ghostty-web-demo
Demo oficial @ghostty-web/demo (https://www.npmjs.com/package/@ghostty-web/demo) com o terminal dentro de um iframe, para o botao Teclado forcar o foco (FB-001).
Rodar: cd apps/ghosttyWebDemo;npm i;npm start  |  porta: PORT=9000 npm start
Abrir: http://localhost:8080
- / = quadro (iframe + botao Teclado); /term = terminal original
- Alteracoes vs demo.js: FRAME_HTML, rota /term, window.term = term
- AVISO: shell sem token; so uso local. (Nao cumpre FR-003 da spec; ver specs/001-webterm.)
- Teclado virtual: nao testado; so humano valida.
