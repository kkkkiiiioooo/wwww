# PRD webtermv2
## Requisitos
- R1: terminal ocupa 100% da tela (sem titulo, margem ou borda).
- R2: PTY real por conexao via WebSocket.
- R3: TOKEN obrigatorio (?t=); sem token, 401 e WebSocket recusado. Sem TOKEN no ambiente, gera aleatorio e imprime a URL.
- R4: HOST (0.0.0.0), PORT (8080), TOKEN, SHELL.
- R5: redimensiona com a janela e com o teclado virtual (visualViewport).
- R6: botao Teclado forca o foco (FB-001).
- R7: reconecta sozinho (2 s).
- R8: sem framework de UI; setNoDelay no socket.
## Rodar
cd apps/webtermv2;npm i;TOKEN=abc npm start   (abrir http://IP:8080/?t=abc)
## Aceite
- [x] / sem token 401; com token 200; /dist e wasm 200 (testado 2026-10-18)
- [x] WebSocket recusa token errado; PTY ecoa em ~2 ms local
- [ ] Atraso no dispositivo lento menor que o v1 (humano)
- [ ] Teclado virtual abre pelo botao (humano)
- [ ] Redimensiona com teclado aberto (humano)
## Fora de escopo
Abas, temas, histórico, multiusuario.
