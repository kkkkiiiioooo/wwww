import http from 'http';import fs from 'fs';import path from 'path';import crypto from 'crypto';
import{fileURLToPath}from'url';import{createRequire}from'module';
import pty from'@lydell/node-pty';import{WebSocketServer}from'ws';
const dir=path.dirname(fileURLToPath(import.meta.url)),req=createRequire(import.meta.url);
const root=req.resolve('ghostty-web').replace(/[/\\]dist[/\\].*$/,'');
const{PORT=8080,HOST='0.0.0.0'}=process.env,SH=process.env.SHELL||'/bin/bash';
const TOKEN=process.env.TOKEN||crypto.randomBytes(6).toString('hex');
const T={'.js':'text/javascript','.wasm':'application/wasm','.html':'text/html'};
const ok=(u)=>u.searchParams.get('t')===TOKEN;
const srv=http.createServer((q,r)=>{
  const u=new URL(q.url,'http://x'),p=u.pathname;
  const send=(f)=>fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end()}
    r.writeHead(200,{'Content-Type':T[path.extname(f)]||'application/octet-stream'});r.end(d)});
  if(p==='/'){if(!ok(u)){r.writeHead(401);return r.end('401')}return send(path.join(dir,'index.html'))}
  if(p.startsWith('/dist/'))return send(path.join(root,'dist',path.basename(p)));
  if(p==='/ghostty-vt.wasm')return send(path.join(root,'ghostty-vt.wasm'));
  r.writeHead(404);r.end()});
srv.on('connection',(s)=>s.setNoDelay(true));
const wss=new WebSocketServer({noServer:true});
srv.on('upgrade',(q,s,h)=>{const u=new URL(q.url,'http://x');
  if(u.pathname!=='/ws'||!ok(u)){s.destroy();return}wss.handleUpgrade(q,s,h,(ws)=>conn(ws,u))});
function conn(ws,u){
  const p=pty.spawn(SH,[],{name:'xterm-256color',cols:+u.searchParams.get('cols')||80,rows:+u.searchParams.get('rows')||24,cwd:process.env.HOME,env:process.env});
  p.onData((d)=>ws.readyState===1&&ws.send(d));p.onExit(()=>ws.close());
  ws.on('message',(m)=>{const s=m.toString();
    if(s[0]==='{'){try{const j=JSON.parse(s);if(j.type==='resize'){p.resize(j.cols,j.rows);return}}catch{}}p.write(s)});
  ws.on('close',()=>p.kill())}
srv.listen(PORT,HOST,()=>console.log(`http://IP:${PORT}/?t=${TOKEN}`));
