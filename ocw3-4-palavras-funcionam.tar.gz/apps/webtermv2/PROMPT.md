# PROMPT webtermv2 (subprojeto independente; nao depende do webtermv1 nem do opencode)
Agente: siga ../../AGENTS.md; leia ../../FEEDBACK.md antes. Humano: edite livremente (~30 linhas).

## Objetivo
Terminal em tela cheia no navegador, sem framework (sem SolidJS), minimo e rapido.

## Contexto
O v1 (opencode/SolidJS) tem atraso de ~3 s no dispositivo lento. O demo oficial perde espaco da tela. Base: ghostty-web + PTY via WebSocket.

## Restricoes
Poucas linhas e poucas dependencias (ghostty-web, ws, @lydell/node-pty). TOKEN obrigatorio.

## Aceite
PRD.md, secao Aceite. Provas em ../../TESTLOG.md.

## Proibido
Frameworks de UI; abas, barras ou molduras; ler imagens sem autorizacao.

## Prioridade atual
1. Medir atraso no dispositivo lento (A/B com o v1).
2. Botao Teclado abrir o teclado virtual (so o humano valida).

## Sugestoes de melhoria (so o agente escreve; humano promove)
- (vazio)

## Versoes
- v1 2026-10-18: criado
