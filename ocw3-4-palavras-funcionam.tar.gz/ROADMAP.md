# Roteiro

## Fase 1 - Fundacao do repositorio
- Criar arquivos markdown principais
- Adicionar imagens de referencia visual
- Adicionar regras visuais
- Adicionar arquivos de fallback de OCR
- Adicionar arquivos de estado da interface

## Fase 2 - Fortalecimento da orientacao dos agentes
- Adicionar arquivo de objetivo explicito
- Adicionar arquivo de memoria persistente
- Adicionar arquivo de roteiro
- Adicionar regras mais fortes em `AGENTS.md`
- Reduzir a ambiguidade entre imagens, OCR e arquivos de contexto

## Fase 3 - Fluxos de trabalho estruturados
- Adicionar definicoes de fluxo de trabalho
- Adicionar padroes reutilizaveis para mais pares de telas
- Adicionar lista de verificacao de validacao para a saida dos agentes
- Adicionar convencoes de nomenclatura para novos arquivos de referencia

## Fase 4 - Escalabilidade
- Suportar multiplos cenarios de atual para desejado
- Adicionar modelos para futuros projetos
- Adicionar metadados legiveis por maquina para agentes
- Adicionar verificacoes automaticas para documentacao faltante
