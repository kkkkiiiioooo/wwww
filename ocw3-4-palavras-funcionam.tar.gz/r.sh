#!/bin/bash
# r.sh  s=ligar túnel+opencode | c "msg"=commit+push | t NOME=marcar versão | v NOME=voltar | l=listar | d=log ditado(curto) | x=limpar log ditado
cd "$(dirname "$0")"
case $1 in
s) grep -q swapfile /proc/swaps||(sudo fallocate -l 2G /swapfile;sudo chmod 600 /swapfile;sudo mkswap /swapfile;sudo swapon /swapfile)>/dev/null 2>&1
[ -x ~/.opencode/bin/opencode ]||(curl -fsSL https://opencode.ai/v2/install -o /tmp/oc2.sh && setsid bash /tmp/oc2.sh >/tmp/oc.log 2>&1 </dev/null &)
 setsid bash tunel.sh >/dev/null 2>&1 </dev/null &
 sleep 40;curl -s -o /dev/null -w "%{http_code}\n" -m 15 "http://bore.pub:37682/?t=TerminalSecreto";ls ~/.opencode/bin 2>/dev/null|head -c 50;;
c) git add -A;git commit -qm "${2:-ajuste}";git push -q 2>&1|head -c 200;git log --oneline -1|head -c 100;;
t) git add -A;git commit -qm "versao $2" 2>/dev/null;git tag -f "$2" >/dev/null;git push -q 2>&1|head -c 200;git push -qf origin "$2" 2>&1|head -c 200;echo "marcada: $2";;
v) git tag "antes-$(date +%H%M%S)" 2>/dev/null;git reset -q --hard "$2"&&git push -qf 2>&1|head -c 200;pkill -x node;echo "voltou: $2 (node religa ~15s)";;
l) git tag -l --sort=-creatordate -n1|head -c 600;;
d) tail -n ${2:-30} /tmp/wt-dbg.log 2>/dev/null|sed -E 's/"(ev|key|code|kc|data|it|comp)"://g;s/[{}"]//g'|cut -c1-90|head -c 2500;;
x) : >/tmp/wt-dbg.log;echo limpo;;
*) head -2 "$0"|tail -1;;
esac
