# Memoria

## Proposito
Este arquivo armazena a memoria operacional persistente dos agentes que trabalham neste repositorio.

## Fatos persistentes atuais
- O objetivo visual e limpar a tela e deixar somente o terminal visivel.
- `screenshot/estado_atual_tela_completa.png` mostra o estado atual.
- `screenshot/estado_desejado_apenas_terminal.png` mostra o estado desejado.
- Se o agente tem visao, as imagens sao a fonte primaria de verdade.
- Se o agente nao tem visao, deve usar `SCREEN_INTENT.md`, `VISUAL_RULES.md`, `ocr/` e `ui_state/`.
- OCR e uma camada de fallback para agentes sem visao.

## Regras de interacao com o usuario
- Nao corrija mentalmente as mensagens do usuario.
- Nao use caracteres acentuados.
- Nao use scroll.
- Prefira navegacao por teclado quando possivel.
- Se o calendario estiver aberto, pare imediatamente.
- Se o mouse estiver sobre o calendario, pare imediatamente.

## Premissas de trabalho
- Mantenha as instrucoes explicitas e faceis de seguir para os agentes.
- Prefira nomes de arquivos simples e explicacoes diretas.
- Mantenha a interpretacao visual alinhada em todos os documentos.

## Politica de atualizacao
Adicione aqui decisoes importantes, preferencias estaveis do usuario e restricoes recorrentes.
Nao armazene notas temporarias que ficarao desatualizadas rapidamente.
