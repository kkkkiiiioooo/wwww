# Feature Specification: webterm (terminal unico no navegador)

**Status**: Draft | **Created**: 2026-10-17 | **Fonte**: PROMPT.md, PRD.md, FEEDBACK.md

## User Scenarios & Testing

### User Story 1 - Terminal funcional (Priority: P1)
Abro a URL com token e uso um shell real.
**Independent Test**: abrir ws com token, enviar "echo ok", receber "ok".
**Acceptance Scenarios**:
1. **Given** servidor ativo, **When** acesso sem token, **Then** resposta 401.
2. **Given** token valido, **When** envio "echo ok", **Then** recebo "ok".

### User Story 2 - Teclado virtual ao focar (Priority: P1)
Ao tocar o terminal, o teclado virtual abre (FB-001).
**Independent Test**: validacao humana em dispositivo real (agente nao valida).
**Acceptance Scenarios**:
1. **Given** terminal sem foco, **When** toco nele, **Then** o teclado virtual aparece.

### User Story 3 - Abas (Priority: P2)
Terminal 1, Terminal 2 e "+", cada um com PTY independente.
**Acceptance Scenarios**:
1. **Given** duas abas, **When** executo comando em uma, **Then** a outra nao e afetada.

### Edge Cases
- Resize da janela nao deve quebrar o PTY.
- Reconexao do WebSocket apos queda (nao testado).
- RAM menor que 2 GB: usar alternativa minima (xterm.js).

## Requirements
### Functional Requirements
- **FR-001**: Pagina unica mostra somente terminal e abas.
- **FR-002**: PTY real por aba via WebSocket.
- **FR-003**: Acesso exige TOKEN (?t=TOKEN).
- **FR-004**: Configuravel por HOST, PORT (5173), TOKEN, SHELL.
- **FR-005**: Sobe com um comando (sh run.sh).
- **FR-006**: Foco no terminal abre o teclado virtual.
- **FR-007**: [NEEDS CLARIFICATION: layout do teclado virtual proprio ou o do sistema?]

### Key Entities
- **Aba**: id, titulo, PTY associado.
- **Sessao**: token, conexoes WebSocket.

## Success Criteria
- **SC-001**: CHECKLIST.md 100% marcado com provas no TESTLOG.md.
- **SC-002**: Consumo proximo de 60 MB RSS com 2 abas.
- **SC-003**: FB-001 RESOLVIDO, validado pelo humano.

## Assumptions
- Sandbox sem navegador: validacao por HTTP/WebSocket.
- Base: apps/webtermv1; alternativa xterm.js.
