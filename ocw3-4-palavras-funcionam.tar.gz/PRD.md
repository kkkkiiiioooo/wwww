# PRD
## Requisitos
- R1: pagina unica com so terminal e abas (Terminal 1/2, "+").
- R2: PTY real via WebSocket (shell do SHELL).
- R3: acesso protegido por TOKEN (?t=TOKEN); sem token, 401.
- R4: variaveis HOST, PORT (5173), TOKEN, SHELL.
- R5: roda com um comando: sh run.sh.
- R6: consumo baixo (referencia: 60 MB RSS com 2 terminais).
## Nao-requisitos
Editor, gerenciador de arquivos, servidor de agente.
