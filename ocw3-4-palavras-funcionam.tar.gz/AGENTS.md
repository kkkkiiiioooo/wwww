# Regras para agentes
- Pedir autorizacao ANTES de expor. Para expor terminal/servico: rodar `setsid ./tunel.sh &` (nunca gerar token ou link novo).
- Token fixo (senha): TerminalSecreto. Link fixo: http://bore.pub:37682/?t=TerminalSecreto
- Se "port already in use": o loop do script tenta de novo a cada 5 s (porta antiga expira).
- Alternativa com subdominio fixo (precisa registrar chave 1x em serveo.net): ssh -R terminalsecreto:80:localhost:7681 serveo.net
- Link curto estavel: criar 1x no bit.ly apontando para o link fixo acima.
- Skill curta: skills/tunel/SKILL.md (ler antes de qualquer tunel)
- Vigia: tunel.sh agora fiscaliza a cada 15 s (servidor local + URL publica) e se religa sozinho. Log /tmp/tunel.log. Se o sandbox morrer, religar: setsid bash tunel.sh &
- Documentacao completa da v4: apps/webtermv4/README.md
- Espera p/ teste: bash ~/ocw3/e.sh (sleep 165 + curl) -- usar em vez de comando longo

## Retomada rápida (chat novo)
1. git clone https://agentgit.co/ocw3.git; cd ocw3  (Composio, nunca bash_tool: precisa de internet)
2. bash r.sh s  -> swap + túnel + teste 200 (link: http://bore.pub:37682/?t=TerminalSecreto)
3. Versões: bash r.sh t NOME (marcar) | bash r.sh v NOME (voltar) | bash r.sh l (listar) | bash r.sh c "msg" (commit+push)
4. Limitar toda saída (head -c, tr -cd '\11\12\15\40-\176'). Última ação de cada resposta: bash ~/ocw3/e.sh
5. agentgit apaga o repo 24h após o último push: espelhar também no GitHub.

Ler também: OBSERVACOES.md (ditado por voz, opencode, preferências).
