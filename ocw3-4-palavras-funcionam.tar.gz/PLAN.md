# Plano
1. Ler AGENTS.md e CHECKLIST.md.
2. Testar server.js (npm i; node server.js) e validar R2/R3.
3. Se dist/ ausente e RAM < 2 GB: usar alternativa minima (xterm.js).
4. Validar CHECKLIST.md; atualizar STATE.md; push.
