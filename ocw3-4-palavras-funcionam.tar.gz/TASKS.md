# TAREFAS
- [x] Definir escopo (PRD.md)
- [x] Definir arquitetura (ARCHITECTURE.md)
- [ ] Rodar server.js e validar PTY+token
- [ ] Validar abas e resize
- [x] Botao teclado virtual injetado no v1 (kb.html); falta teste humano
- [ ] Testar apps/ghosttyWebDemo no dispositivo (botao Teclado abre o teclado?)
- [ ] Marcar CHECKLIST.md

- [x] webtermv4 (light, sem abas, xterm.js) criado; falta teste humano
- [x] tunel.sh + AGENTS.md: link fixo bore.pub:37682 token TerminalSecreto
- [x] v4 funcionando na TV Samsung (teclado ok); espaco corrigido (teste humano pendente); tunel.sh com vigia (testado)
