#!/bin/bash
# Supervisor: mantem node(v4)+bore no ar e testa ponta a ponta (URL publica) a cada 15 s.
# Uso: setsid bash tunel.sh &   |  log: /tmp/tunel.log  |  link: /tmp/tunel.link
D="$(cd "$(dirname "$0")" && pwd)/apps/webtermv4";T=TerminalSecreto;LP=7681;RP=${RP:-37682};LOG=/tmp/tunel.log
[ -d "$D/node_modules" ]||(cd "$D"&&npm i --silent)
B=$(command -v bore||echo /tmp/bore)
[ -x "$B" ]||{ curl -sL https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-x86_64-unknown-linux-musl.tar.gz|tar xz -C /tmp;B=/tmp/bore;}
[ -f /tmp/tunel.pid ]&&kill $(cat /tmp/tunel.pid) 2>/dev/null;echo $$>/tmp/tunel.pid
code(){ curl -s -o /dev/null -w %{http_code} -m "$2" "$1"; }
node_up(){ [ "$(code "localhost:$LP/?t=$T" 3)" = 200 ]&&return
 P=$(ss -ltnp 2>/dev/null|grep ":$LP "|grep -o 'pid=[0-9]*'|cut -d= -f2|head -1);[ -n "$P" ]&&kill -9 $P
 (cd "$D";TOKEN=$T PORT=$LP setsid node server.js >/tmp/wt.log 2>&1 </dev/null &);sleep 2;echo "$(date +%T) node reiniciado">>$LOG;}
bore_up(){ pkill -9 -x bore;sleep 1;setsid $B local $LP --to bore.pub --port $RP >/tmp/bore.log 2>&1 </dev/null &
 sleep 4;echo "$(date +%T) bore reiniciado (porta $RP)">>$LOG;echo "http://bore.pub:$RP/?t=$T">/tmp/tunel.link;}
pub_ok(){ [ "$(code "http://bore.pub:$RP/?t=$T" 8)" = 200 ];}
pkill -9 -x bore;node_up;bore_up;cat /tmp/tunel.link;f=0;iu=0
while :;do sleep 15;node_up
 if pub_ok;then f=0;iu=0;else f=$((f+1));echo "$(date +%T) publico falhou ($f)">>$LOG
  if [ $f -ge 2 ];then
   grep -q "in use" /tmp/bore.log&&iu=$((iu+1))
   [ $iu -ge 8 ]&&{ RP=$((RP+1));iu=0;echo "$(date +%T) porta presa, usando $RP">>$LOG;}
   bore_up;f=0;fi;fi
done
