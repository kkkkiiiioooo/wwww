# Intencao da tela (fallback sem visao)
Atual: terminal existe, mas ha outros elementos visiveis. Acao: remover/ocultar tudo que nao e terminal.
Desejado: so o terminal visivel, abas Terminal 1/2 e "+", sem browser/gerenciador de arquivos. Detalhes em ocr/ e ui_state/.
