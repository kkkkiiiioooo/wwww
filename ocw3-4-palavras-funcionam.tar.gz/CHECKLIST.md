# Checklist de aceite
- [ ] cd apps/webtermv1; npm i; TOKEN=x PORT=5173 node server.js sobe sem erro
- [ ] curl -s -o /dev/null -w "%{http_code}" localhost:5173/ sem token -> 401
- [ ] curl com ?t=x -> 200 e HTML
- [ ] WebSocket abre PTY e "echo ok" retorna ok (ex.: npx wscat)
- [ ] Duas abas = dois PTYs independentes
- [ ] Resize nao quebra o PTY
- [ ] UI final: so o terminal (compare com screenshot/estado_desejado_apenas_terminal.png)
- [ ] Teclado virtual: so humano valida
