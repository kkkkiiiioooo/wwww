# Fluxo de trabalho

## Proposito
Este arquivo define o fluxo de execucao padrao para humanos e agentes que trabalham neste repositorio.

## Fluxo padrao
1. Leia `README.md` para a visao geral do projeto.
2. Leia `PROMPT.md` para o objetivo atual.
3. Leia `AGENTS.md` para as regras de comportamento dos agentes.
4. Leia `CONTEXT.md` e `VISUAL_RULES.md` para as regras de interpretacao.
5. Se o agente tem visao, use as imagens de referencia como fonte primaria.
6. Se o agente nao tem visao, use `SCREEN_INTENT.md`, `ocr/` e `ui_state/` como fontes de fallback.
7. Revise `PLAN.md`, `ROADMAP.md` e `TASKS.md` antes de fazer alteracoes.
8. Atualize os arquivos de forma consistente quando o entendimento do projeto mudar.
9. Valide o trabalho contra `CHECKLIST.md` antes de considerar a tarefa concluida.
10. Registre achados estaveis em `MEMORY.md` quando necessario.

## Fluxo de trabalho visual
- `screenshot/estado_atual_tela_completa.png` mostra o estado atual.
- `screenshot/estado_desejado_apenas_terminal.png` mostra o estado desejado.
- O objetivo e remover distracoes e deixar somente o terminal visivel.

## Fluxo de trabalho de documentacao
- Use `PRD.md` para requisitos.
- Use `ARCHITECTURE.md` para a estrutura tecnica.
- Use `DECISIONS.md` e `docs/decisions/` para decisoes notaveis.
- Use `STATE.md` para o estado atual do projeto.

## Fluxo de atualizacao
Ao adicionar uma nova regra ou referencia:
1. Atualize o arquivo fonte mais relevante.
2. Atualize `DOCS_INDEX.md` se um novo documento for adicionado.
3. Atualize `MEMORY.md` se a regra for persistente.
4. Atualize `TASKS.md` se houver trabalho de acompanhamento.
