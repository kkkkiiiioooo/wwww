# Changelog
Formato: Keep a Changelog (https://keepachangelog.com). Agente: adicione uma linha em "Nao lancado" a cada alteracao relevante.

## [Nao lancado]
### Adicionado
- apps/ghosttyWebDemo/auth.js: demo oficial com TOKEN (pagina e WebSocket) e log de abertura/fechamento do WebSocket; script/d.sh usa ele com token de 4 palavras
- script/d.sh: preview publico do demo oficial @ghostty-web/demo sem alteracoes (sem token; uso curto)
- script/p.sh: preview publico do webtermv2 via cloudflared (quick tunnel), token aleatorio de 4 palavras sem acento por execucao
- apps/webtermv2: terminal em tela cheia, sem SolidJS (ghostty-web + ws + node-pty), TOKEN obrigatorio; PROMPT.md e PRD.md proprios
- apps/ghosttyWebDemo: demo oficial @ghostty-web/demo com terminal em iframe e botao Teclado (HTTP ok; teclado nao validado)
- FEEDBACK.md (caixa de entrada do humano) e FB-001 (teclado virtual nao abre ao focar o terminal)
- CHANGELOG.md
- AGENTS.md, CONTEXT.md, VISUAL_RULES.md, SCREEN_INTENT.md, CHECKLIST.md, DOCS_INDEX.md, ui_state/, docs/decisions/
### Alterado
- script/p.sh e d.sh: cloudflared com --protocol http2 (QUIC/UDP derrubava o tunel: 'no recent network activity')
- GOAL, PRD, ARCHITECTURE, PLAN, TASKS, HANDOFF, STATE reescritos para "agente constroi o webterm"
- Caminhos images/ trocados por screenshot/
### Pendente
- Validar o webterm com o CHECKLIST.md (nada foi executado ainda)

## [Historico anterior ao commit 49540d1]
- Estrutura inicial de docs, imagens e OCR
- App webtermv1 (PTY + servidor Node), run.sh e build.sh
- Pasta images renomeada para screenshot; .gitignore e node_modules fora do git
