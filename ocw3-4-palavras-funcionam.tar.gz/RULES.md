# Regras

## Regras do repositorio
- Mantenha os nomes dos documentos explicitos e legiveis.
- Prefira um arquivo por responsabilidade clara.
- Nao trate a imagem do estado atual como o estado final desejado.
- Mantenha o estado atual e o estado desejado claramente separados.
- Mantenha a orientacao para visao e nao visao alinhada.

## Regras dos agentes
- Se a visao estiver disponivel, use as imagens como fonte primaria para interpretacao da tela.
- Se a visao nao estiver disponivel, use `SCREEN_INTENT.md`, `VISUAL_RULES.md`, `ocr/` e `ui_state/`.
- Nao deixe o OCR sobrescrever evidencia visual clara quando a visao existir.
- Leia o objetivo e o contexto antes de agir.
- Escreva na memoria somente informacoes estaveis que devem persistir.

## Regras de documentacao
- Atualize `DOCS_INDEX.md` ao adicionar documentos importantes.
- Atualize `STATE.md` quando o status do repositorio mudar.
- Atualize `DECISIONS.md` quando uma decisao importante for tomada.
- Use `TASKS.md` para itens de trabalho executaveis.
- Use `ROADMAP.md` para direcao por fases, nao para listas detalhadas de tarefas.
