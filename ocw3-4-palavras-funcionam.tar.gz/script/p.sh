#!/bin/sh
# Preview publico do webtermv2 via cloudflared (quick tunnel). Uso: sh script/p.sh
# Opcoes: PORT=8080  N=4 (palavras do token)  TOKEN=minha-senha
cd "$(dirname "$0")/../apps/webtermv2"||exit 1
PORT=${PORT:-8080};N=${N:-4}
W="abacaxi aurora bambu barco bisao bolsa brisa bussola cacto camelo canoa carvao castelo cereja cobalto cometa coral coruja cristal dado delta diamante dragao duna eclipse escudo espelho esfera estrela falcao farol fenix floresta fogueira fonte fosforo furacao gaivota galaxia gelo girassol glacial granito harpa hera horizonte iceberg ilha jacare jade jangada jasmim kiwi lagarto lanterna lareira leao lenha limao lobo lume lunar machado magnolia mamute mangue mapa marfim meteoro minerio montanha musgo navio neblina nuvem oasis obsidiana oceano onix opala orquidea pantera papiro pedra penhasco pergaminho pinguim pirata planeta pluma polvo ponte prisma pulsar quartzo quimera raio rapina recife relampago rubi safira salgueiro savana selva serpente sol tartaruga tempestade tigre topazio tornado trevo trigo trovao tundra turmalina urso vento vidro violeta vulcao xadrez zenite zebra zefiro"
TOKEN=${TOKEN:-$(shuf -n"$N" -e $W|paste -sd-)}
export PORT TOKEN HOST=127.0.0.1
B=$HOME/.local/bin;mkdir -p "$B";PATH=$B:$PATH
command -v cloudflared >/dev/null||{ a=amd64;[ "$(uname -m)" = aarch64 ]&&a=arm64
  curl -fsSL -o "$B/cloudflared" https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$a&&chmod +x "$B/cloudflared"||exit 1; }
[ -d node_modules ]||npm i -s
node server.js >/tmp/wt.log 2>&1 &
S=$!
trap 'kill $S $C 2>/dev/null' EXIT INT TERM
cloudflared tunnel --no-autoupdate --protocol http2 --url http://127.0.0.1:$PORT >/tmp/cf.log 2>&1 &
C=$!
echo "aguardando tunel..."
for i in $(seq 40);do U=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cf.log|head -1);[ -n "$U" ]&&break;sleep 1;done
[ -n "$U" ]||{ echo "falhou; veja /tmp/cf.log";exit 1; }
for i in $(seq 25);do [ "$(curl -s -o /dev/null -w %{http_code} "$U/?t=$TOKEN")" = 200 ]&&break;sleep 1;done
echo "$U/?t=$TOKEN"
echo "Ctrl+C encerra"
wait $C
