#!/bin/sh
# Preview publico do demo (@ghostty-web/demo + token + log de conexoes, em apps/ghosttyWebDemo/auth.js) via cloudflared.
# Uso: sh script/d.sh   (N=4 palavras, TOKEN=..., PORT=8081)
D=$(dirname "$0");W=$(sed -n 's/^W="\(.*\)"$/\1/p' "$D/p.sh")
cd "$D/../apps/ghosttyWebDemo"||exit 1
export TOKEN=${TOKEN:-$(shuf -n"${N:-4}" -e $W|paste -sd-)}
export PORT=${PORT:-8081}
B=$HOME/.local/bin;mkdir -p "$B";PATH=$B:$PATH
command -v cloudflared >/dev/null||{ a=amd64;[ "$(uname -m)" = aarch64 ]&&a=arm64
  curl -fsSL -o "$B/cloudflared" https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$a&&chmod +x "$B/cloudflared"||exit 1; }
[ -d node_modules ]||npm i -s
node auth.js >/tmp/demo.log 2>&1 &
S=$!
trap 'kill $S $C 2>/dev/null' EXIT INT TERM
cloudflared tunnel --no-autoupdate --protocol http2 --url http://127.0.0.1:$PORT >/tmp/cfd.log 2>&1 &
C=$!
echo "aguardando tunel..."
for i in $(seq 40);do U=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cfd.log|head -1);[ -n "$U" ]&&break;sleep 1;done
[ -n "$U" ]||{ echo "falhou; veja /tmp/cfd.log";exit 1; }
for i in $(seq 25);do [ "$(curl -s -o /dev/null -w %{http_code} "$U/?t=$TOKEN")" = 200 ]&&break;sleep 1;done
echo "$U/?t=$TOKEN"
echo "Ctrl+C encerra"
wait $C
