# TESTLOG (provas dos testes)
Agente: a cada item do CHECKLIST.md executado, adicione uma linha. Sem linha aqui, o item NAO esta pronto.
Humano: itens de teclado virtual so valem com a sua linha.

| Data | Item (CHECKLIST) | Comando | Resultado | Quem |
|------|------------------|---------|-----------|------|
| 2026-10-18 | webtermv2 HTTP/token | curl / sem e com token, /dist, wasm | 401, 200, 200, 200 | agente |
| 2026-10-18 | webtermv2 PTY/WebSocket | node ws: echo ok2; token errado | eco 2 ms local; recusado | agente |
| 2026-10-18 | script/p.sh tunel | sh script/p.sh no sandbox Composio | cloudflared registrou o tunel e a URL foi impressa; acesso publico NAO verificado (sandbox nao resolve DNS trycloudflare) | agente |
| 2026-10-18 | demo auth.js | curl e ws locais | sem token 401; com token 200; ws errado recusado; ws certo abre; log registra abertura e fechamento | agente |
| 2026-10-18 | demo local ws 20s | node ws em localhost:8081 | conexao ficou aberta 20 s; sem erro no tunel http2 | agente |
