---
name: "tunel"
description: "Ao expor qualquer porta/servidor/terminal na internet (tunel, túnel, bore, link público). Preferir bore. PEDIR AUTORIZAÇÃO antes de expor."
---
1. ANTES de expor: pedir autorização ao usuário (botões clicáveis). Sem OK, não expor.
2. Preferir bore (sem conta/chave, funciona bem). Outros (serveo, cloudflared, pinggy) só se bore falhar.
3. Instalar: curl -sL https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-x86_64-unknown-linux-musl.tar.gz|tar xz -C /tmp
4. Usar: setsid /tmp/bore local PORTA --to bore.pub --port PORTAFIXA &  -> http://bore.pub:PORTAFIXA
5. Rodar via Composio (bash_tool sem internet). Mostrar o link por extenso. Processo morre com o sandbox: religar.
Exemplo salvo: git clone https://agentgit.co/ocw3.git; setsid ./ocw3/tunel.sh & -> http://bore.pub:37682/?t=TerminalSecreto
