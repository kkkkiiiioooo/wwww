# FEEDBACK (caixa de entrada do humano para os agentes)

Regras:
- Humano: adicione itens no FIM, status ABERTO. Escreva curto; so sintoma e esperado.
- Agente: leia este arquivo ANTES de qualquer tarefa. ABERTO tem prioridade sobre TASKS.md.
- Agente: ao resolver, mude para RESOLVIDO, preencha Resolucao e Evidencia, atualize STATE.md, commit e push.
- Nao apague itens; historico e a documentacao.

## FB-001 | ABERTO | 2026-10-17
- Sintoma: ao tocar/focar o terminal, o teclado virtual nao aparece.
- Esperado: foco no terminal abre o teclado virtual (TV/Gboard).
- Pistas (agente verifica): foco real no textarea oculto do terminal, chamada de focus() no toque, atributo inputmode.
- Resolucao: (preencher)
- Evidencia: (preencher; so humano valida teclado virtual)

## Modelo
## FB-NNN | ABERTO | AAAA-MM-DD
- Sintoma:
- Esperado:
- Resolucao:
- Evidencia:
